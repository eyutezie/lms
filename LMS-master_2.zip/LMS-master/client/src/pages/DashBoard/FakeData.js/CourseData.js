const courseData=[
    {
        title:"ICE3101_12539_B",
        name:"Analysis and Design of Algorithm ICE3101_12539_B"
    },
    {
        title:"ICE3101_12539_B",
        name:"Analysis and Design of Algorithm ICE3101_12539_B"
    },
    {
        title:"ICE3101_12539_B",
        name:"Analysis and Design of Algorithm ICE3101_12539_B"
    },
    {
        title:"ICE3101_12539_B",
        name:"Analysis and Design of Algorithm ICE3101_12539_B"
    },
    {
        title:"ICE3101_12539_B",
        name:"Analysis and Design of Algorithm ICE3101_12539_B"
    },
    {
        title:"ICE3101_12539_B",
        name:"Analysis and Design of Algorithm ICE3101_12539_B"
    },
    {
        title:"ICE3101_12539_B",
        name:"Analysis and Design of Algorithm ICE3101_12539_B"
    },
    {
        title:"ICE3101_12539_B",
        name:"Analysis and Design of Algorithm ICE3101_12539_B"
    },
    {
        title:"ICE3101_12539_B",
        name:"Analysis and Design of Algorithm ICE3101_12539_B"
    },
    {
        title:"ICE3101_12539_B",
        name:"Analysis and Design of Algorithm ICE3101_12539_B"
    },
    {
        title:"ICE3101_12539_B",
        name:"Analysis and Design of Algorithm ICE3101_12539_B"
    },
    {
        title:"ICE3101_12539_B",
        name:"Analysis and Design of Algorithm ICE3101_12539_B"
    },
    {
        title:"ICE3101_12539_B",
        name:"Analysis and Design of Algorithm ICE3101_12539_B"
    },
    {
        title:"ICE3101_12539_B",
        name:"Analysis and Design of Algorithm ICE3101_12539_B"
    },
    {
        title:"ICE3101_12539_B",
        name:"Analysis and Design of Algorithm ICE3101_12539_B"
    },
    {
        title:"ICE3101_12539_B",
        name:"Analysis and Design of Algorithm ICE3101_12539_B"
    },
]

export default courseData